package OrangeHRMLogin;

import org.openqa.selenium.chrome.ChromeDriver;


import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
// io.github.bonigarcia.wdm.WebDriverManager;
//import org.openqa.selenium.WebElement;

public class OrangeHRMLoginTest 
{

	public static void main(String[] args) throws InterruptedException 
	{
		// 1st launch browser 
		// System.setProperty("webriver.chrome.driver","C:\\Driver\\chromedriver_win32\\chromedriver"); or other way is 
		//WebDriverManager.chromedriver().setup();
		
		/* Note : We do not need to use above two lines of code after 4.6.0 version it will automatically launch launch browser so, we do not need 
		web driver manager in pom.xma file */
		
		//Launch browser 
		// ChromeDriver driver = new ChromeDriver();
		
		//instead of above line we can mention webdriver 
		
		WebDriver driver = new ChromeDriver(); //we use this because we can work with multiple browser 
		
		//open url in the browser 
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.manage().window().maximize(); //open window in fullscreen and also known as method chaining
		Thread.sleep(7000);
		
		//provide username -admin
		/* WebElement txtUsername = driver.findElement(By.name("username"));
		txtUsername.sendKeys("Admin"); */
		
		//Instead of above two line we can write a code in a below single line 
		driver.findElement(By.name("username")).sendKeys("Admin");
		
		//Provide password - admin123
		driver.findElement(By.name("password")).sendKeys("admin123");
		
		//Click on login/submit button
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
		Thread.sleep(10000);
		
		//verify title of dashboard page 
		//Title validation 
		
		/* String act_title = driver.getTitle();
		String exp_title = "OrangeHRM";
		
		if(act_title.equals(exp_title))
		{
			System.out.println("Test Passed");
		}
		else 
		{
			System.out.println("Test Failed");
		} */
		
		
		//Label validation after successful login
		String act_label = null;
		try 
		{
		act_label = driver.findElement(By.xpath("//*[@id='app']/div[1]/div[1]/header/div[1]/div[1]/span/h6")).getText();
		}
		catch (NoSuchElementException e) 
		{
			act_label = ""; 
		}
		
		String exp_label = "Dashboard";
		
		if (act_label.equals(exp_label))
		{
			System.out.println ("Test Passed");
		}
		else 
		{
			System.out.println ("Test Failed");
		}
		// Close Browser 
		// driver.close(); //throw connection reset error due to this line 
		//driver.quit();
	}	

}